package com.ev.dao.user;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ev.dto.station.EvChargerDTO;
import com.ev.dto.station.EvChargingStationDTO;
import com.ev.dto.station.EvStationMapDTO;

@Mapper
public interface EvStationDAO {

    /*
     충전소 목록 조회
     keyword가 없으면 전체 충전소 조회.
     keyword가 있으면 충전소명, 주소, 운영기관명으로 검색.
	*/
    List<EvChargingStationDTO> findStationList(@Param("keyword") String keyword);

    // 충전소 상세 조회
   
    EvChargingStationDTO findStationById(@Param("stationId") Long stationId);

    // 특정 충전소에 속한 충전기 목록 조회
     
    List<EvChargerDTO> findChargerListByStationId(@Param("stationId") Long stationId);
    
    // 카카오맵에 표시할 충전소 목록 조회
    List<EvStationMapDTO> findStationMapList(@Param("keyword") String keyword,
                                             @Param("connectorType") String connectorType);

    // 사용자가 선택한 출발지 좌표 기준 가까운 충전소 목록 조회
    List<EvStationMapDTO> findStationMapListByCoordinate(@Param("keyword") String keyword,
                                                          @Param("connectorType") String connectorType,
                                                          @Param("latitude") Double latitude,
                                                          @Param("longitude") Double longitude,
                                                          @Param("limit") int limit);

    /*
     * 기본 출발지 주변 운영중 충전소 수 조회
     */
    int countNearbyStationByDefaultLocation(@Param("memberId") Long memberId,
                                            @Param("radiusMeter") int radiusMeter);

    /*
     * 기본 출발지 주변 사용 가능한 충전기 수 조회
     */
    int countAvailableChargerByDefaultLocation(@Param("memberId") Long memberId,
                                               @Param("radiusMeter") int radiusMeter);

    /*
     * 기본 출발지 주변 추천 충전소 목록 조회
     */
    List<EvStationMapDTO> findNearbyStationListByDefaultLocation(@Param("memberId") Long memberId,
                                                                 @Param("radiusMeter") int radiusMeter,
                                                                 @Param("limit") int limit);
}